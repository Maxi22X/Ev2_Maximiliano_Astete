﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEMESTRE
{
    internal class DatosSemestres
    {

        public int? id_ { get; set; }

        public string? nombre_ { get; set; }

        //pendiente agregar avriables tipo int

    }
}
