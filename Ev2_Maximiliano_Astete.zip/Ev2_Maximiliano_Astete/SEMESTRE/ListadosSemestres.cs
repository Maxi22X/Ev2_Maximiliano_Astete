﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEMESTRE
{
    internal class ListadosSemestres
    {
        static public List<DatosSemestres> ListaSemestres = new List<DatosSemestres>();

        static public int IDSemestre = 1; 
    }
}
