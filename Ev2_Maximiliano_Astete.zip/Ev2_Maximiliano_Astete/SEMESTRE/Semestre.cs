namespace SEMESTRE
{
    public partial class Semestre : Form
    {
        public Semestre()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombres = txtNombreSemestre.Text;
           /* int a�o = int.Parse(txtA�o.Text);
              int estado = int.Parse((string)cbxEstado.SelectedItem); Produce que se caiga la app */

            if (nombres == "")
            {

                MessageBox.Show("Campos no pueden estar vacios."); //pendiente validaci�n de las variables tipo Int

            }
            else
            {
                ListadosSemestres.ListaSemestres.Add(new DatosSemestres()
                {
                    id_ = ListadosSemestres.IDSemestre,
                    nombre_ = nombres
                });

                ListadosSemestres.IDSemestre = ListadosSemestres.IDSemestre + 1;

                dgvSemestres.Rows.Clear();
                foreach (var item in ListadosSemestres.ListaSemestres)
                {
                    dgvSemestres.Rows.Add(item.id_,
                                          item.nombre_);

                }

                txtNombreSemestre.Clear();
            }




        }
    }
}
