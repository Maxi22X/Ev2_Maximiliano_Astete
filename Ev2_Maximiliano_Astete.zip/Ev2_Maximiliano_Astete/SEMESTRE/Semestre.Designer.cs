﻿namespace SEMESTRE
{
    partial class Semestre
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            cbxEstado = new ComboBox();
            label3 = new Label();
            txtNombreSemestre = new TextBox();
            txtAño = new TextBox();
            dgvSemestres = new DataGridView();
            btnGuardar = new Button();
            btnLimpiar = new Button();
            gpbIngresoSemestre = new GroupBox();
            ID = new DataGridViewTextBoxColumn();
            NOMBRE = new DataGridViewTextBoxColumn();
            AÑO = new DataGridViewTextBoxColumn();
            ESTADO = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvSemestres).BeginInit();
            gpbIngresoSemestre.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 28);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 0;
            label1.Text = "NOMBRE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(331, 28);
            label2.Name = "label2";
            label2.Size = new Size(33, 15);
            label2.TabIndex = 1;
            label2.Text = "AÑO";
            // 
            // cbxEstado
            // 
            cbxEstado.FormattingEnabled = true;
            cbxEstado.Location = new Point(551, 59);
            cbxEstado.Name = "cbxEstado";
            cbxEstado.Size = new Size(136, 23);
            cbxEstado.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(546, 28);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 3;
            label3.Text = "ESTADO";
            // 
            // txtNombreSemestre
            // 
            txtNombreSemestre.Location = new Point(15, 59);
            txtNombreSemestre.Name = "txtNombreSemestre";
            txtNombreSemestre.Size = new Size(213, 23);
            txtNombreSemestre.TabIndex = 11;
            // 
            // txtAño
            // 
            txtAño.Location = new Point(331, 59);
            txtAño.Name = "txtAño";
            txtAño.Size = new Size(74, 23);
            txtAño.TabIndex = 10;
            // 
            // dgvSemestres
            // 
            dgvSemestres.AllowUserToAddRows = false;
            dgvSemestres.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSemestres.Columns.AddRange(new DataGridViewColumn[] { ID, NOMBRE, AÑO, ESTADO });
            dgvSemestres.Location = new Point(12, 184);
            dgvSemestres.Name = "dgvSemestres";
            dgvSemestres.Size = new Size(776, 254);
            dgvSemestres.TabIndex = 12;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(693, 129);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(77, 31);
            btnGuardar.TabIndex = 13;
            btnGuardar.Text = "GUARDAR";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(6, 129);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(77, 31);
            btnLimpiar.TabIndex = 14;
            btnLimpiar.Text = "LIMPIAR";
            btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // gpbIngresoSemestre
            // 
            gpbIngresoSemestre.Controls.Add(btnLimpiar);
            gpbIngresoSemestre.Controls.Add(btnGuardar);
            gpbIngresoSemestre.Controls.Add(txtNombreSemestre);
            gpbIngresoSemestre.Controls.Add(label1);
            gpbIngresoSemestre.Controls.Add(txtAño);
            gpbIngresoSemestre.Controls.Add(label2);
            gpbIngresoSemestre.Controls.Add(label3);
            gpbIngresoSemestre.Controls.Add(cbxEstado);
            gpbIngresoSemestre.Location = new Point(12, 12);
            gpbIngresoSemestre.Name = "gpbIngresoSemestre";
            gpbIngresoSemestre.Size = new Size(776, 166);
            gpbIngresoSemestre.TabIndex = 15;
            gpbIngresoSemestre.TabStop = false;
            gpbIngresoSemestre.Text = "INGRESAR SEMESTRE";
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // NOMBRE
            // 
            NOMBRE.HeaderText = "NOMBRE";
            NOMBRE.Name = "NOMBRE";
            // 
            // AÑO
            // 
            AÑO.HeaderText = "AÑO";
            AÑO.Name = "AÑO";
            // 
            // ESTADO
            // 
            ESTADO.HeaderText = "ESTADO";
            ESTADO.Name = "ESTADO";
            // 
            // Semestre
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(gpbIngresoSemestre);
            Controls.Add(dgvSemestres);
            Name = "Semestre";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SEMESTRE";
            ((System.ComponentModel.ISupportInitialize)dgvSemestres).EndInit();
            gpbIngresoSemestre.ResumeLayout(false);
            gpbIngresoSemestre.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private ComboBox cbxEstado;
        private Label label3;
        private TextBox txtNombreSemestre;
        private TextBox txtAño;
        private DataGridView dgvSemestres;
        private Button btnGuardar;
        private Button btnLimpiar;
        private GroupBox gpbIngresoSemestre;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NOMBRE;
        private DataGridViewTextBoxColumn AÑO;
        private DataGridViewTextBoxColumn ESTADO;
    }
}
