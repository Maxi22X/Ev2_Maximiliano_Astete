namespace INGRESO_NOTAS
{
    public partial class NOTAS : Form
    {
        public NOTAS()
        {
            InitializeComponent();
        }
    }
}
