﻿namespace Menu_Principal
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            ingresoAlumnosToolStripMenuItem = new ToolStripMenuItem();
            ingresoAsignaturaToolStripMenuItem = new ToolStripMenuItem();
            ingrsoAsignaturasToolStripMenuItem = new ToolStripMenuItem();
            ingresoCursosToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripMenuItem();
            ingresoNotasToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.BackColor = SystemColors.ActiveBorder;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.FlatStyle = FlatStyle.System;
            label1.Font = new Font("Verdana", 30F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(150, 67);
            label1.MaximumSize = new Size(1000, 100);
            label1.Name = "label1";
            label1.Size = new Size(384, 100);
            label1.TabIndex = 0;
            label1.Text = "Gestión Académica";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { ingresoAlumnosToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(697, 24);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // ingresoAlumnosToolStripMenuItem
            // 
            ingresoAlumnosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ingresoAsignaturaToolStripMenuItem, ingrsoAsignaturasToolStripMenuItem, ingresoCursosToolStripMenuItem, toolStripMenuItem1, ingresoNotasToolStripMenuItem });
            ingresoAlumnosToolStripMenuItem.Name = "ingresoAlumnosToolStripMenuItem";
            ingresoAlumnosToolStripMenuItem.Size = new Size(95, 20);
            ingresoAlumnosToolStripMenuItem.Text = "Mantenedores";
            // 
            // ingresoAsignaturaToolStripMenuItem
            // 
            ingresoAsignaturaToolStripMenuItem.Name = "ingresoAsignaturaToolStripMenuItem";
            ingresoAsignaturaToolStripMenuItem.Size = new Size(172, 22);
            ingresoAsignaturaToolStripMenuItem.Text = "Ingreso Alumnos";
            // 
            // ingrsoAsignaturasToolStripMenuItem
            // 
            ingrsoAsignaturasToolStripMenuItem.Name = "ingrsoAsignaturasToolStripMenuItem";
            ingrsoAsignaturasToolStripMenuItem.Size = new Size(172, 22);
            ingrsoAsignaturasToolStripMenuItem.Text = "Ingrso Asignaturas";
            // 
            // ingresoCursosToolStripMenuItem
            // 
            ingresoCursosToolStripMenuItem.Name = "ingresoCursosToolStripMenuItem";
            ingresoCursosToolStripMenuItem.Size = new Size(172, 22);
            ingresoCursosToolStripMenuItem.Text = "Ingreso Cursos";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(172, 22);
            // 
            // ingresoNotasToolStripMenuItem
            // 
            ingresoNotasToolStripMenuItem.Name = "ingresoNotasToolStripMenuItem";
            ingresoNotasToolStripMenuItem.Size = new Size(172, 22);
            ingresoNotasToolStripMenuItem.Text = "Ingreso Notas";
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(697, 251);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Principal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Principal";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem ingresoAlumnosToolStripMenuItem;
        private ToolStripMenuItem ingresoAsignaturaToolStripMenuItem;
        private ToolStripMenuItem ingrsoAsignaturasToolStripMenuItem;
        private ToolStripMenuItem ingresoCursosToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem ingresoNotasToolStripMenuItem;
    }
}
