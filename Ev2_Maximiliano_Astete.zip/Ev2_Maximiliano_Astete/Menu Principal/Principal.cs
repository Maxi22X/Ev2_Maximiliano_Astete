namespace Menu_Principal
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }
    }
}
