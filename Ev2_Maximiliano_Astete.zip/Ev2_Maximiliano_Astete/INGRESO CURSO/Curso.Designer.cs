﻿namespace INGRESO_CURSO
{
    partial class Curso
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cbxAsignatura = new ComboBox();
            gpbIngresoCurso = new GroupBox();
            btnGuardar = new Button();
            dgvCursos = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            CURS0 = new DataGridViewTextBoxColumn();
            gpbIngresoCurso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCursos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(310, 46);
            label1.Name = "label1";
            label1.Size = new Size(77, 15);
            label1.TabIndex = 3;
            label1.Text = "ASIGNATURA";
            // 
            // cbxAsignatura
            // 
            cbxAsignatura.FormattingEnabled = true;
            cbxAsignatura.Location = new Point(60, 82);
            cbxAsignatura.Name = "cbxAsignatura";
            cbxAsignatura.Size = new Size(643, 23);
            cbxAsignatura.TabIndex = 2;
            // 
            // gpbIngresoCurso
            // 
            gpbIngresoCurso.Controls.Add(btnGuardar);
            gpbIngresoCurso.Controls.Add(label1);
            gpbIngresoCurso.Controls.Add(cbxAsignatura);
            gpbIngresoCurso.Location = new Point(22, 30);
            gpbIngresoCurso.Name = "gpbIngresoCurso";
            gpbIngresoCurso.Size = new Size(756, 173);
            gpbIngresoCurso.TabIndex = 4;
            gpbIngresoCurso.TabStop = false;
            gpbIngresoCurso.Text = "INGRESAR CURSOS";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(646, 134);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 4;
            btnGuardar.Text = "GUARDAR";
            btnGuardar.UseVisualStyleBackColor = true;
            // 
            // dgvCursos
            // 
            dgvCursos.AllowUserToAddRows = false;
            dgvCursos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCursos.Columns.AddRange(new DataGridViewColumn[] { ID, CURS0 });
            dgvCursos.Location = new Point(22, 224);
            dgvCursos.Name = "dgvCursos";
            dgvCursos.Size = new Size(756, 202);
            dgvCursos.TabIndex = 5;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // CURS0
            // 
            CURS0.HeaderText = "CURS0";
            CURS0.Name = "CURS0";
            // 
            // Curso
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvCursos);
            Controls.Add(gpbIngresoCurso);
            Name = "Curso";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "INGRESO CURSO";
            gpbIngresoCurso.ResumeLayout(false);
            gpbIngresoCurso.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCursos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private ComboBox cbxAsignatura;
        private GroupBox gpbIngresoCurso;
        private Button btnGuardar;
        private DataGridView dgvCursos;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn CURS0;
    }
}
