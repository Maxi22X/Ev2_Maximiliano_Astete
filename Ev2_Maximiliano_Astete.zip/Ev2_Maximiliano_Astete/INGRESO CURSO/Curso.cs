namespace INGRESO_CURSO
{
    public partial class Curso : Form
    {
        public Curso()
        {
            InitializeComponent();
        }
    }
}
