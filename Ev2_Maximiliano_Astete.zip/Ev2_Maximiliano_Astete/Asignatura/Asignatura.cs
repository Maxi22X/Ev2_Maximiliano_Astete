using INGRESO_ASIGNATURA;

namespace Asignatura
{
    public partial class Asignatura : Form
    {
        public Asignatura()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombreAsignatura.Text;
            string semestre = cbxSemestre.Text;

            if (nombre == "" || semestre == "")
            {
                MessageBox.Show("Campos no pueden estar vacios.");
            }
            else
            {
                ListadosAsignatura.ListaAsignatura.Add(new DatosAsignatura()
                {
                    id_ = ListadosAsignatura.IDAsignatura,
                    nomrbe_ = nombre,
                    semestre_ = semestre    
                }
                );

                ListadosAsignatura.IDAsignatura = ListadosAsignatura.IDAsignatura + 1;

                dgvAsignaturas.Rows.Clear();
                foreach (var item in ListadosAsignatura.ListaAsignatura)
                {
                    dgvAsignaturas.Rows.Add(item.id_,
                                            item.nomrbe_,
                                            item.semestre_);
                }

                txtNombreAsignatura.Clear();
                cbxSemestre.Items.Clear();
               

            }


        }
    }
}
