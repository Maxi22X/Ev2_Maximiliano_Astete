﻿namespace Asignatura
{
    partial class Asignatura
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gpbIngresoAsignatura = new GroupBox();
            txtNombreAsignatura = new TextBox();
            label2 = new Label();
            btnGuardar = new Button();
            label1 = new Label();
            cbxSemestre = new ComboBox();
            dgvAsignaturas = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            NOMBRE = new DataGridViewTextBoxColumn();
            SEMESTRE = new DataGridViewTextBoxColumn();
            gpbIngresoAsignatura.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAsignaturas).BeginInit();
            SuspendLayout();
            // 
            // gpbIngresoAsignatura
            // 
            gpbIngresoAsignatura.Controls.Add(txtNombreAsignatura);
            gpbIngresoAsignatura.Controls.Add(label2);
            gpbIngresoAsignatura.Controls.Add(btnGuardar);
            gpbIngresoAsignatura.Controls.Add(label1);
            gpbIngresoAsignatura.Controls.Add(cbxSemestre);
            gpbIngresoAsignatura.Location = new Point(24, 26);
            gpbIngresoAsignatura.Name = "gpbIngresoAsignatura";
            gpbIngresoAsignatura.Size = new Size(729, 175);
            gpbIngresoAsignatura.TabIndex = 0;
            gpbIngresoAsignatura.TabStop = false;
            gpbIngresoAsignatura.Text = "INGRESAR ASIGNATURA";
            // 
            // txtNombreAsignatura
            // 
            txtNombreAsignatura.Location = new Point(34, 82);
            txtNombreAsignatura.Name = "txtNombreAsignatura";
            txtNombreAsignatura.Size = new Size(213, 23);
            txtNombreAsignatura.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 44);
            label2.Name = "label2";
            label2.Size = new Size(56, 15);
            label2.TabIndex = 3;
            label2.Text = "NOMBRE";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(629, 137);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 2;
            btnGuardar.Text = "GUARDAR";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(552, 44);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 1;
            label1.Text = "SEMESTRE";
            // 
            // cbxSemestre
            // 
            cbxSemestre.FormattingEnabled = true;
            cbxSemestre.Location = new Point(552, 82);
            cbxSemestre.Name = "cbxSemestre";
            cbxSemestre.Size = new Size(121, 23);
            cbxSemestre.TabIndex = 0;
            // 
            // dgvAsignaturas
            // 
            dgvAsignaturas.AllowUserToAddRows = false;
            dgvAsignaturas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAsignaturas.Columns.AddRange(new DataGridViewColumn[] { ID, NOMBRE, SEMESTRE });
            dgvAsignaturas.Location = new Point(24, 216);
            dgvAsignaturas.Name = "dgvAsignaturas";
            dgvAsignaturas.Size = new Size(729, 222);
            dgvAsignaturas.TabIndex = 1;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // NOMBRE
            // 
            NOMBRE.HeaderText = "NOMBRE";
            NOMBRE.Name = "NOMBRE";
            // 
            // SEMESTRE
            // 
            SEMESTRE.HeaderText = "SEMESTRE";
            SEMESTRE.Name = "SEMESTRE";
            // 
            // Asignatura
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(771, 450);
            Controls.Add(dgvAsignaturas);
            Controls.Add(gpbIngresoAsignatura);
            Name = "Asignatura";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "INGRESO ASIGNATURA";
            gpbIngresoAsignatura.ResumeLayout(false);
            gpbIngresoAsignatura.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAsignaturas).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gpbIngresoAsignatura;
        private Label label1;
        private ComboBox cbxSemestre;
        private Label label2;
        private Button btnGuardar;
        private TextBox txtNombreAsignatura;
        private DataGridView dgvAsignaturas;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NOMBRE;
        private DataGridViewTextBoxColumn SEMESTRE;
    }
}
