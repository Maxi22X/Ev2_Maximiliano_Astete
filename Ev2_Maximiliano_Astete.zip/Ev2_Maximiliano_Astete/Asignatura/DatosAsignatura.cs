﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INGRESO_ASIGNATURA
{
    internal class DatosAsignatura
    {
        public int id_ {  get; set; }

        public string? nomrbe_ { get; set; }

        public string? semestre_ {  get; set; }

    }

}
