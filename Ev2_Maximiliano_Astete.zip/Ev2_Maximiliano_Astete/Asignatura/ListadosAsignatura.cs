﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INGRESO_ASIGNATURA
{
    internal class ListadosAsignatura
    {
        static public List<DatosAsignatura> ListaAsignatura = new List<DatosAsignatura>();

        static public int IDAsignatura = 1;
    }
}
