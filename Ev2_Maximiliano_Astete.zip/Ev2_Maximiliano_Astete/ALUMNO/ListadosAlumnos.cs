﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALUMNO
{
    internal class ListadosAlumnos
    {
        static public List<DatosAlumnos> ListaAlumnos = new List<DatosAlumnos>();
       
        static public int IDAlumno = 1;
    }
}
