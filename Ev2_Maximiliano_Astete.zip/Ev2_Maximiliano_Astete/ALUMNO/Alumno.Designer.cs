﻿namespace ALUMNO
{
    partial class Alumno
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtApellidos = new TextBox();
            dgvAlumnos = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            NOMBRES = new DataGridViewTextBoxColumn();
            APELLIDOS = new DataGridViewTextBoxColumn();
            MATRICULAS = new DataGridViewTextBoxColumn();
            btnGuardar = new Button();
            label2 = new Label();
            label3 = new Label();
            txtMatricula = new TextBox();
            lblNombre = new Label();
            txtNombres = new TextBox();
            gpbRegistroAlumnos = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dgvAlumnos).BeginInit();
            gpbRegistroAlumnos.SuspendLayout();
            SuspendLayout();
            // 
            // txtApellidos
            // 
            txtApellidos.Location = new Point(426, 36);
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(117, 23);
            txtApellidos.TabIndex = 1;
            // 
            // dgvAlumnos
            // 
            dgvAlumnos.AllowUserToAddRows = false;
            dgvAlumnos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAlumnos.Columns.AddRange(new DataGridViewColumn[] { ID, NOMBRES, APELLIDOS, MATRICULAS });
            dgvAlumnos.Location = new Point(14, 165);
            dgvAlumnos.Name = "dgvAlumnos";
            dgvAlumnos.Size = new Size(856, 293);
            dgvAlumnos.TabIndex = 3;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // NOMBRES
            // 
            NOMBRES.HeaderText = "NOMBRES";
            NOMBRES.Name = "NOMBRES";
            // 
            // APELLIDOS
            // 
            APELLIDOS.HeaderText = "APELLIDOS";
            APELLIDOS.Name = "APELLIDOS";
            // 
            // MATRICULAS
            // 
            MATRICULAS.HeaderText = "MATRICULAS";
            MATRICULAS.Name = "MATRICULAS";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(743, 103);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 4;
            btnGuardar.Text = "GUARDAR";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(332, 39);
            label2.Name = "label2";
            label2.Size = new Size(72, 15);
            label2.TabIndex = 6;
            label2.Text = "APELLIDOS :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(608, 39);
            label3.Name = "label3";
            label3.Size = new Size(77, 15);
            label3.TabIndex = 8;
            label3.Text = "MATRICULA :";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(699, 36);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(119, 23);
            txtMatricula.TabIndex = 7;
            txtMatricula.KeyPress += txtMatricula_KeyPress;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(31, 39);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(71, 15);
            lblNombre.TabIndex = 10;
            lblNombre.Text = "NOMBRES : ";
            // 
            // txtNombres
            // 
            txtNombres.Location = new Point(124, 36);
            txtNombres.Name = "txtNombres";
            txtNombres.Size = new Size(168, 23);
            txtNombres.TabIndex = 9;
            // 
            // gpbRegistroAlumnos
            // 
            gpbRegistroAlumnos.Controls.Add(lblNombre);
            gpbRegistroAlumnos.Controls.Add(btnGuardar);
            gpbRegistroAlumnos.Controls.Add(txtApellidos);
            gpbRegistroAlumnos.Controls.Add(txtNombres);
            gpbRegistroAlumnos.Controls.Add(label2);
            gpbRegistroAlumnos.Controls.Add(label3);
            gpbRegistroAlumnos.Controls.Add(txtMatricula);
            gpbRegistroAlumnos.Location = new Point(12, 12);
            gpbRegistroAlumnos.Name = "gpbRegistroAlumnos";
            gpbRegistroAlumnos.Size = new Size(856, 147);
            gpbRegistroAlumnos.TabIndex = 11;
            gpbRegistroAlumnos.TabStop = false;
            gpbRegistroAlumnos.Text = "REGISTRAR ALUMNOS";
            // 
            // Alumno
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(882, 484);
            Controls.Add(gpbRegistroAlumnos);
            Controls.Add(dgvAlumnos);
            Name = "Alumno";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ALUMNO";
            ((System.ComponentModel.ISupportInitialize)dgvAlumnos).EndInit();
            gpbRegistroAlumnos.ResumeLayout(false);
            gpbRegistroAlumnos.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox txtApellidos;
        private DataGridView dgvAlumnos;
        private Button btnGuardar;
        private Label label2;
        private Label label3;
        private TextBox txtMatricula;
        private Label lblNombre;
        private TextBox txtNombres;
        private GroupBox gpbRegistroAlumnos;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NOMBRES;
        private DataGridViewTextBoxColumn APELLIDOS;
        private DataGridViewTextBoxColumn MATRICULAS;
    }
}
