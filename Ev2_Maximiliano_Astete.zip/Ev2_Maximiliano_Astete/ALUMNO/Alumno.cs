namespace ALUMNO
{
    public partial class Alumno : Form
    {
        public Alumno()
        {
            InitializeComponent();
        }



        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombres = txtNombres.Text;
            string apellidos = txtApellidos.Text;
            string matricula = txtMatricula.Text;
            //int matricula = int.Parse(txtMatricula.Text);


            if (nombres == "" || apellidos == "" || matricula == "")
            {
                MessageBox.Show("Campos no pueden estar vacios.");
            }
            else
            {
                ListadosAlumnos.ListaAlumnos.Add(new DatosAlumnos()

                {
                    id_ = ListadosAlumnos.IDAlumno,
                    nombre_ = nombres,
                    apellido_ = apellidos,
                    matricula_ = matricula
                });

                ListadosAlumnos.IDAlumno = ListadosAlumnos.IDAlumno + 1;

                dgvAlumnos.Rows.Clear();
                foreach (var item in ListadosAlumnos.ListaAlumnos)
                {
                    dgvAlumnos.Rows.Add(item.id_,
                                      item.nombre_,
                                      item.apellido_,
                                      item.matricula_);

                }

            }

            txtMatricula.Clear();
            txtApellidos.Clear();
            txtNombres.Clear();
        }

        private void txtMatricula_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 32 && e.KeyChar <= 47 || e.KeyChar >= 58 && e.KeyChar <= 255)
            {
                MessageBox.Show("solo numeros", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                txtMatricula.Clear();
                return;

            }
        }

       
    }
}
